let buttonColors = ["red", "blue", "green", "yellow"];
let gamePattern = [];
let userClickPattern = [];
let randomChosenColor = null;

$(document).keypress(function(){
randomChosenColor = buttonColors[nextSequence()];
gamePattern.push(randomChosenColor);
$("#"+randomChosenColor).animate({opacity: "0%"}, 100).animate({opacity: "100%"}, 100);
})

$(".btn").on("click", function(){
    $("#"+this.id).animate({opacity: "0%"}, 100).animate({opacity: "100%"}, 100);
    userClickPattern.push(this.id);
    if (this.id == randomChosenColor){
        playSound(this.id);
        randomChosenColor = buttonColors[nextSequence()];
        gamePattern.push(randomChosenColor);
    } else {
        playSound();
    }
});


// let sound = new Audio("sounds/"+randomChosenColor+".mp3");
// sound.play();

function nextSequence(){
    let randomNumber = parseInt(Math.random()*4);
    return randomNumber;
}

function playSound(key){
    switch (key) {
        case "red":
            let sound0 = new Audio('sounds/red.mp3');
            sound0.play();
            break;
        case "blue":
            let sound1 = new Audio('sounds/blue.mp3');
            sound1.play();
            break;
        case "green":
            let sound2 = new Audio('sounds/green.mp3');
            sound2.play();
            break;    
        case "yellow":
            let sound3 = new Audio('sounds/yellow.mp3');
            sound3.play();
            break;
    
        default: 
            let sound4 = new Audio('sounds/wrong.mp3');
            sound4.play();
            break;
    }
    
}